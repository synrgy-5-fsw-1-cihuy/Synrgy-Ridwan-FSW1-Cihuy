function sortCarByYearAscendingly(cars) {
  // Sangat dianjurkan untuk console.log semua hal hehe
  console.log(cars);

  // Clone array untuk menghindari side-effect
  // Apa itu side effect?
  const result = [...cars];

  // Tulis code-mu disini

  for (let row = 0; row < result.length; row++) {
    for (let column = 0; column < result.length - row - 1; column++) {
      if (result[column]['year'] > result[column + 1]['year']) {
        let temp = result[column];
        result[column] = result[column + 1];
        result[column + 1] = temp;
      }
    }
    
  }
  // console.log(result);


  // Rubah code ini dengan array hasil sorting secara ascending
  return result;
}
